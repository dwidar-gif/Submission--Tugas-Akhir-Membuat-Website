# Skilvul x Garena

Demo project loading animation